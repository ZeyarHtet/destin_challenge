class Song {
  late String src;
  String? title;
  String? artist;
  String? albumn;

  Song({required this.src, this.title, this.artist, this.albumn});
}
